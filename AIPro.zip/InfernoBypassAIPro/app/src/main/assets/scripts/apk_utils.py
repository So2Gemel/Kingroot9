import zipfile
import os

def list_apk_libs(apk_path):
    libs = []
    with zipfile.ZipFile(apk_path, 'r') as zip_ref:
        for file in zip_ref.namelist():
            if file.endswith(".so"):
                libs.append(file)
    return libs