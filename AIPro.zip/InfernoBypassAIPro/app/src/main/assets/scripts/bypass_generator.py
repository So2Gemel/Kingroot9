def generate_bypass_code(function_names):
    bypass_code = ""
    for name in function_names:
        bypass_code += f"HOOK('{name}', Bypass_{name});\n"
    return bypass_code