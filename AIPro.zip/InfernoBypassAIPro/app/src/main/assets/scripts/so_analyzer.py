import os
import re

def analyze_so(file_path):
    if not os.path.exists(file_path):
        return "File not found."

    with open(file_path, 'rb') as f:
        content = f.read()

    functions = re.findall(rb'_ZN[\w\d_]+', content)
    decoded = [func.decode('utf-8', errors='ignore') for func in functions]
    unique_funcs = list(set(decoded))
    return unique_funcs[:50]  # إرجاع أول 50 دالة تحليلًا