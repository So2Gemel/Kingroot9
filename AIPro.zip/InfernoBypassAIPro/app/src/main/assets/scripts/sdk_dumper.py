import zipfile
import os

def extract_sdk(apk_path, output_dir):
    if not zipfile.is_zipfile(apk_path):
        return "Invalid APK file."
    
    with zipfile.ZipFile(apk_path, 'r') as zip_ref:
        for file in zip_ref.namelist():
            if 'libUE4.so' in file or 'lib' in file:
                zip_ref.extract(file, output_dir)
    return "SDK extraction completed."